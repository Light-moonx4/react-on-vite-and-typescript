import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-800">
      <Link href="/" className="font-bold text-xl">Al Catálogo</Link>
      <div className="flex gap-4">
        <Link href="/" className="hover:text-blue-500">Inicio</Link>
        <Link href="/events" className="hover:text-blue-500">Eventos</Link>
        <Link href="/categories" className="hover:text-blue-500">Categorías</Link>
      </div>
    </nav>
  );
}