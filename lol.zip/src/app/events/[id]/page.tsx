import Link from "next/link";
import { sampleEvents } from "../page";

interface EventDetailPageProps {
  params: Promise<{
    id: string;
  }>;
}

export default async function EventDetailPage({ params }: EventDetailPageProps) {
  const { id } = await params;
  const event = sampleEvents.find((e) => e.id === id);

  if (!event) {
    return (
      <div className="mx-auto max-w-xl p-8 text-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Evento no encontrado (ID: {id})
        </h1>
        <p className="mt-2 text-gray-600 dark:text-gray-400">
          No existe ningún evento registrado con ese identificador.
        </p>
        <Link
          href="/events"
          className="mt-4 inline-block rounded-lg bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-500 transition-colors"
        >
          Volver a Eventos
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl p-6">
      <Link
        href="/events"
        className="text-sm text-blue-500 hover:underline inline-block mb-6"
      >
        &larr; Volver al catálogo de eventos
      </Link>

      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 p-6 bg-white dark:bg-gray-900 shadow-sm">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
              {event.date}
            </span>
            <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mt-1">
              {event.title}
            </h1>
          </div>
          <span className="rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-sm font-bold px-3 py-1">
            {event.price}
          </span>
        </div>

        <div className="mt-4 text-sm text-gray-500">
          📍 Lugar: <span className="font-medium text-gray-700 dark:text-gray-300">{event.location}</span>
        </div>

        <hr className="my-6 border-gray-200 dark:border-gray-800" />

        <div>
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
            Descripción del Evento
          </h2>
          <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
            {event.description}
          </p>
        </div>

        <div className="mt-8 pt-4 border-t border-gray-100 dark:border-gray-800 flex gap-4">
          <button
            type="button"
            className="flex-1 rounded-lg bg-blue-600 py-2.5 text-center text-sm font-semibold text-white hover:bg-blue-500 transition-colors"
          >
            Comprar Entradas ({event.price})
          </button>
        </div>
      </div>
    </div>
  );
}
