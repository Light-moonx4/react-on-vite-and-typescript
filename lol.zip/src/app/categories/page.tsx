import Link from "next/link";

export default function CategoriesPage() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 p-8">
      <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
        Categorías
      </h1>
      <p className="text-gray-600 dark:text-gray-400">
        Explora las distintas categorías de eventos.
      </p>
      <div className="flex gap-4 mt-4">
        <Link href="/" className="text-blue-500 hover:underline">
          Volver al Inicio
        </Link>
        <Link href="/events" className="text-blue-500 hover:underline">
          Ver Eventos
        </Link>
      </div>
    </div>
  );
}
