import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { favoriteService } from '../services/favoriteService';
import { ApiError } from '../error/ApiError';
import { useAuth } from './AuthContext';
import { extractEventIdFromFavorite, normalizeFavoritesList } from '../utils/favoriteUtils';

interface FavoritesContextType {
  favoriteIds: Set<string>;
  isFavorite: (eventId: string) => boolean;
  toggleFavorite: (eventId: string) => Promise<void>;
  loading: boolean;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

/**
 * Mantiene en memoria el conjunto de productIds favoritos del usuario actual,
 * para que el ícono de favorito y la vista "Mis favoritos" se actualicen sin
 * recargar la página al agregar/quitar.
 */
export const FavoritesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);

  /* eslint-disable react-hooks/set-state-in-effect -- resetea el estado local al cerrar sesión */
  useEffect(() => {
    if (!isAuthenticated) {
      setFavoriteIds(new Set());
      return;
    }
    let cancelled = false;
    setLoading(true);
    favoriteService
      .getMine()
      .then((rawFavorites) => {
        if (!cancelled) {
          const list = normalizeFavoritesList(rawFavorites);
          const ids = list
            .map(extractEventIdFromFavorite)
            .filter((id): id is string => Boolean(id));
          setFavoriteIds(new Set(ids));
        }
      })
      .catch(() => {
        // Si falla la carga inicial de favoritos, simplemente empezamos vacíos.
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [isAuthenticated]);
  /* eslint-enable react-hooks/set-state-in-effect */

  const isFavorite = useCallback((eventId: string) => favoriteIds.has(eventId), [favoriteIds]);

  const toggleFavorite = useCallback(
    async (eventId: string) => {
      const currentlyFavorite = favoriteIds.has(eventId);
      try {
        if (currentlyFavorite) {
          await favoriteService.remove(eventId);
          setFavoriteIds((prev) => {
            const next = new Set(prev);
            next.delete(eventId);
            return next;
          });
        } else {
          await favoriteService.add(eventId);
          setFavoriteIds((prev) => {
            const next = new Set(prev);
            next.add(eventId);
            return next;
          });
        }
      } catch (err) {
        // 409 (ya estaba en favoritos) o 404 (no estaba): igual sincronizamos el
        // estado local con lo que realmente refleja la intención del usuario,
        // sin romper la interfaz.
        if (err instanceof ApiError && (err.type === 'CONFLICT_ERROR' || err.type === 'NOT_FOUND_ERROR')) {
          setFavoriteIds((prev) => {
            const next = new Set(prev);
            if (currentlyFavorite) next.delete(eventId);
            else next.add(eventId);
            return next;
          });
          return;
        }
        throw err;
      }
    },
    [favoriteIds]
  );

  return (
    <FavoritesContext.Provider value={{ favoriteIds, isFavorite, toggleFavorite, loading }}>
      {children}
    </FavoritesContext.Provider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components -- se mantiene junto al provider por simplicidad
export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) throw new Error('useFavorites debe usarse dentro de un FavoritesProvider');
  return context;
};
