import { useState } from 'react';
import { extractSingleImageUrl } from '../../utils/imageUtils';

/**
 * Una URL de imagen inválida o rota no debe romper el diseño de la página:
 * si falla la carga, mostramos un placeholder en vez del icono roto del navegador.
 */
export function EventImage({ src, alt, className }: { src?: unknown; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  const [bgColor, setBgColor] = useState<string | null>(null);

  const imageUrl = extractSingleImageUrl(src);

  const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    try {
      const img = e.currentTarget;
      const canvas = document.createElement('canvas');
      canvas.width = 10;
      canvas.height = 10;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, 10, 10);
        const data = ctx.getImageData(0, 0, 10, 10).data;
        let r = 0;
        let g = 0;
        let b = 0;
        let count = 0;
        for (let i = 0; i < data.length; i += 4) {
          r += data[i];
          g += data[i + 1];
          b += data[i + 2];
          count++;
        }
        r = Math.floor(r / count);
        g = Math.floor(g / count);
        b = Math.floor(b / count);
        setBgColor(`rgb(${r}, ${g}, ${b})`);
      }
    } catch {
      // Fallback a fondo difuminado si CORS restringe lectura de píxeles
    }
  };

  if (!imageUrl || failed) {
    return (
      <div
        className={`flex items-center justify-center bg-slate-100 text-xs text-slate-400 ${className ?? ''}`}
      >
        Sin imagen
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden flex items-center justify-center ${className ?? ''}`}
      style={bgColor ? { backgroundColor: bgColor } : undefined}
    >
      {/* Fondo difuminado basado en la paleta de la propia imagen */}
      <img
        src={imageUrl}
        alt=""
        aria-hidden="true"
        className="absolute inset-0 h-full w-full object-cover blur-xl scale-125 opacity-60 pointer-events-none"
      />
      {/* Imagen principal ajustada proporcionalmente y con sus colores 100% nítidos */}
      <img
        src={imageUrl}
        alt={alt}
        crossOrigin="anonymous"
        onLoad={handleImageLoad}
        onError={() => setFailed(true)}
        className="relative z-10 max-h-full max-w-full object-contain"
      />
    </div>
  );
}
