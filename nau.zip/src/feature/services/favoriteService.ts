import { request } from './api';
import type { Favorite } from '../interfaces/Favorite';

export const favoriteService = {
  getMine() {
    return request<unknown>({ url: '/favorites', method: 'GET' });
  },
  async add(eventId: string) {
    try {
      return await request<Favorite>({ url: '/favorites', method: 'POST', data: { eventId } });
    } catch {
      try {
        return await request<Favorite>({ url: '/favorites', method: 'POST', data: { productId: eventId } });
      } catch {
        return await request<Favorite>({ url: '/favorites', method: 'POST', data: { eventId, productId: eventId } });
      }
    }
  },
  async remove(eventId: string) {
    try {
      return await request<void>({ url: `/favorites/${eventId}`, method: 'DELETE' });
    } catch (err) {
      try {
        return await request<void>({ url: `/favorites/event/${eventId}`, method: 'DELETE' });
      } catch {
        throw err;
      }
    }
  },
};
