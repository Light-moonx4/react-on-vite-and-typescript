import type { Event } from '../interfaces/Product';

/**
 * Normaliza la respuesta del backend para /favorites, tolerando:
 * - Arreglos directos [...]
 * - Respuestas paginadas o envueltas { data: [...] }, { favorites: [...] }, { items: [...] }
 */
export function normalizeFavoritesList(res: unknown): any[] {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (typeof res === 'object') {
    const obj = res as Record<string, unknown>;
    if (Array.isArray(obj.data)) return obj.data;
    if (Array.isArray(obj.favorites)) return obj.favorites;
    if (Array.isArray(obj.items)) return obj.items;
  }
  return [];
}

/**
 * Extrae el objeto Event de un elemento de favoritos si viene anidado o si el elemento es el evento mismo.
 */
export function extractEventFromFavorite(item: any): Event | null {
  if (!item || typeof item !== 'object') return null;

  // Si el elemento es directamente el Evento
  if ('name' in item && ('price' in item || 'capacity' in item || 'location' in item)) {
    return item as Event;
  }

  // Si el evento viene anidado en el objeto Favorito (event, events, product, item)
  const nested = item.event ?? item.events ?? item.product ?? item.item ?? item.data;
  if (nested && typeof nested === 'object' && 'name' in nested) {
    return nested as Event;
  }

  return null;
}

/**
 * Extrae el ID del evento de un elemento de favoritos.
 */
export function extractEventIdFromFavorite(item: any): string | null {
  if (!item || typeof item !== 'object') return null;

  if (typeof item.eventId === 'string' && item.eventId) return item.eventId;
  if (typeof item.productId === 'string' && item.productId) return item.productId;

  // Si el objeto es directamente el Evento
  if ('name' in item && typeof item.id === 'string' && item.id) return item.id;

  // Si el evento viene anidado
  const nested = item.event ?? item.events ?? item.product ?? item.item;
  if (nested && typeof nested === 'object' && typeof nested.id === 'string' && nested.id) {
    return nested.id;
  }

  if (typeof item.id === 'string' && item.id) return item.id;

  return null;
}

