/**
 * Extrae URLs válidas de cualquier estructura de datos recibida del backend
 * (cadena única, arreglos de cadenas, objetos con url/src/path, arreglos de objetos, etc.),
 * ignorando cadenas corruptas como '[object Object]'.
 */
export function extractImageUrls(images: unknown): string[] {
  if (!images) return [];

  if (typeof images === 'string') {
    if (images.trim().startsWith('[object')) return [];
    return images
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0 && !s.startsWith('[object'));
  }

  if (Array.isArray(images)) {
    const urls: string[] = [];
    for (const item of images) {
      if (typeof item === 'string' && !item.startsWith('[object')) {
        const trimmed = item.trim();
        if (trimmed) urls.push(trimmed);
      } else if (item && typeof item === 'object') {
        const obj = item as Record<string, unknown>;
        const rawUrl = obj.url ?? obj.src ?? obj.path ?? obj.link;
        if (typeof rawUrl === 'string' && !rawUrl.startsWith('[object')) {
          const trimmed = rawUrl.trim();
          if (trimmed) urls.push(trimmed);
        }
      }
    }
    return urls;
  }

  if (typeof images === 'object') {
    const obj = images as Record<string, unknown>;
    const rawUrl = obj.url ?? obj.src ?? obj.path ?? obj.link;
    if (typeof rawUrl === 'string' && !rawUrl.startsWith('[object')) {
      const trimmed = rawUrl.trim();
      if (trimmed) return [trimmed];
    }
  }

  return [];
}

export function extractSingleImageUrl(images: unknown): string | undefined {
  const urls = extractImageUrls(images);
  return urls.length > 0 ? urls[0] : undefined;
}

