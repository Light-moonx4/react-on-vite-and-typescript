import { describe, expect, it } from 'vitest';
import {
  extractEventFromFavorite,
  extractEventIdFromFavorite,
  normalizeFavoritesList,
} from '../favoriteUtils';

describe('favoriteUtils', () => {
  it('normalizes direct array', () => {
    expect(normalizeFavoritesList([1, 2])).toEqual([1, 2]);
  });

  it('normalizes wrapped object with data field', () => {
    expect(normalizeFavoritesList({ data: [1, 2] })).toEqual([1, 2]);
  });

  it('extracts event from nested property', () => {
    const fav = { id: 'fav1', event: { id: 'e1', name: 'Concierto', price: 100 } };
    expect(extractEventFromFavorite(fav)).toEqual({ id: 'e1', name: 'Concierto', price: 100 });
  });

  it('extracts event ID from eventId or nested event', () => {
    expect(extractEventIdFromFavorite({ eventId: 'e1' })).toBe('e1');
    expect(extractEventIdFromFavorite({ productId: 'p1' })).toBe('p1');
    expect(extractEventIdFromFavorite({ event: { id: 'e2' } })).toBe('e2');
  });
});

