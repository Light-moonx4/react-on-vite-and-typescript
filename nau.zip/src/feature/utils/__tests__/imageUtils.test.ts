import { describe, expect, it } from 'vitest';
import { extractImageUrls, extractSingleImageUrl } from '../imageUtils';

describe('imageUtils', () => {
  it('handles string URL', () => {
    expect(extractImageUrls('https://example.com/a.png')).toEqual(['https://example.com/a.png']);
  });

  it('filters out [object Object] strings', () => {
    expect(extractImageUrls('[object Object]')).toEqual([]);
  });

  it('handles array of string URLs', () => {
    expect(extractImageUrls(['https://example.com/a.png', 'https://example.com/b.png'])).toEqual([
      'https://example.com/a.png',
      'https://example.com/b.png',
    ]);
  });

  it('handles array of objects with url property', () => {
    expect(extractImageUrls([{ url: 'https://example.com/a.png' }])).toEqual([
      'https://example.com/a.png',
    ]);
  });

  it('handles single object with url property', () => {
    expect(extractImageUrls({ url: 'https://example.com/a.png' })).toEqual([
      'https://example.com/a.png',
    ]);
  });

  it('extractSingleImageUrl returns first valid URL', () => {
    expect(extractSingleImageUrl([{ url: 'https://example.com/a.png' }])).toBe('https://example.com/a.png');
    expect(extractSingleImageUrl('[object Object]')).toBeUndefined();
  });
});

