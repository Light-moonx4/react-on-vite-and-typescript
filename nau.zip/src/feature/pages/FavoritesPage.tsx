import { useEffect, useState } from 'react';
import { useFetch } from '../hooks/useFetch';
import { favoriteService } from '../services/favoriteService';
import { useFavorites } from '../context/FavoritesContext';
import { EventCard } from '../components/events/EventCard';
import { Spinner } from '../components/common/Spinner';
import { ErrorState } from '../components/common/ErrorState';
import { EmptyState } from '../components/common/EmptyState';
import { extractEventFromFavorite, normalizeFavoritesList } from '../utils/favoriteUtils';
import { EventService } from '../services/eventService';
import type { Event } from '../interfaces/Product';

/** Requiere sesión (protegida por <ProtectedRoute />). Lista los productos guardados. */
export function FavoritesPage() {
  // Se suscribe al mismo estado que usa el ícono de cada producto: cuando favoriteIds
  // cambia (agregar/quitar desde cualquier parte de la app), se refetch y la lista
  // se actualiza sin necesidad de recargar la página.
  const { favoriteIds } = useFavorites();
  const favoriteKey = Array.from(favoriteIds).sort().join(',');
  const { data: rawFavorites, loading, error, refetch } = useFetch(() => favoriteService.getMine(), [favoriteKey]);

  const [fetchedEvents, setFetchedEvents] = useState<Event[]>([]);
  const [fetchingExtra, setFetchingExtra] = useState(false);

  const list = normalizeFavoritesList(rawFavorites);
  const directEvents = list
    .map(extractEventFromFavorite)
    .filter((p): p is Event => Boolean(p));

  useEffect(() => {
    // Si la API devolvió favoritos pero sin los detalles del evento incrustados,
    // buscamos individualmente los eventos correspondientes a favoriteIds.
    if (!loading && directEvents.length === 0 && favoriteIds.size > 0) {
      setFetchingExtra(true);
      const ids = Array.from(favoriteIds);
      Promise.all(ids.map((id) => EventService.getById(id).catch(() => null)))
        .then((res) => {
          setFetchedEvents(res.filter((item): item is Event => Boolean(item)));
        })
        .finally(() => setFetchingExtra(false));
    }
  }, [loading, directEvents.length, favoriteKey, favoriteIds]);

  if (loading || fetchingExtra) return <Spinner />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;

  const displayEvents = directEvents.length > 0 ? directEvents : fetchedEvents;

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-slate-800">Mis favoritos</h1>
      {displayEvents.length === 0 ? (
        <EmptyState message="Todavía no has guardado eventos como favoritos." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {displayEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      )}
    </div>
  );
}
