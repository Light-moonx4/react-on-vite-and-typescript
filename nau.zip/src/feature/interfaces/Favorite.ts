import type { Event } from './Product';

export interface Favorite {
  id: string;
  eventId?: string;
  productId?: string;
  userId: string;
  event?: Event;
  events?: Event;
  product?: Event;
  createdAt?: string;
}
